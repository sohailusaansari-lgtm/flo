# Open Generative AI — Modified Edition

## What changed from the original

| Feature | Original | This version |
|---|---|---|
| API key prompt | Modal shown on every launch | Removed — key lives in `.env.local` |
| Balance display | Shown in header | Removed |
| API key storage | localStorage (browser) | Environment variable (server + client) |
| Public URL | localhost only | ngrok (primary) + Cloudflare (fallback) |
| Dependencies | Pinned to older versions | Updated to latest stable |
| Start command | `npm run dev` | `./start.sh` or `npm run dev:tunnel` |

---

## Quick Start

### 1 — Get your Muapi.ai API key
Sign up at [muapi.ai](https://muapi.ai) and copy your access key.

### 2 — Configure environment
```bash
cp .env.local.example .env.local
```
Edit `.env.local`:
```
MUAPI_KEY=your_actual_key_here
NEXT_PUBLIC_MUAPI_KEY=your_actual_key_here
```
> Both variables must be set — `MUAPI_KEY` is used server-side by route handlers,
> `NEXT_PUBLIC_MUAPI_KEY` is bundled into the client.

### 3 — First-time setup
```bash
git submodule update --init --recursive
npm install
npm run build:packages
```

### 4 — Run (local only)
```bash
npm run dev
# App is at http://localhost:3000
```

### 5 — Run with public URL (ngrok + Cloudflare fallback)
```bash
./start.sh
# or
npm run dev:tunnel
```

The tunnel script will:
1. Try to open an **ngrok** tunnel (fast, stable)
2. If ngrok fails, fall back to a **Cloudflare quick tunnel**
3. Print the public URL to your terminal

#### Optional: add your ngrok auth token for longer sessions
```
NGROK_AUTHTOKEN=your_token_here   # in .env.local
```
Get one free at https://dashboard.ngrok.com/get-started/your-authtoken

#### Optional: Cloudflare named tunnel (permanent domain)
```
CF_TUNNEL_TOKEN=your_cf_token    # in .env.local
```
Set up at https://one.dash.cloudflare.com/

---

## Scripts reference

| Command | What it does |
|---|---|
| `npm run dev` | Next.js dev server (hot reload) |
| `npm run build` | Production build |
| `npm run start` | Production server |
| `npm run tunnel` | Launch tunnel only (server must already be running) |
| `npm run dev:tunnel` | Dev server + tunnel together |
| `npm run start:tunnel` | Production server + tunnel together |
| `./start.sh` | All-in-one: deps check + dev + tunnel |
| `./start.sh --prod` | All-in-one: build + prod server + tunnel |
| `./start.sh --no-tunnel` | Dev server, local only |

---

## Architecture notes

- **No API key UI** — The `ApiKeyModal` component and balance-polling logic are fully removed.
  The app starts immediately without asking for anything.
- **Server-side key injection** — Every Next.js route handler (`/api/app`, `/api/workflow`,
  `/api/agents`, `/api/v1`) reads `process.env.MUAPI_KEY` as a last-resort fallback, so
  requests work even when the client-side cookie/header is missing.
- **Tunnel failover** — `tunnel.js` tries ngrok first (npm package, no binary required),
  then cloudflared. Both are installed on-demand if not present.

---

## Troubleshooting

**"Module not found: studio"**
```bash
npm run build:packages
```

**"Submodule directories are empty"**
```bash
git submodule update --init --recursive
npm run build:packages
```

**ngrok ECONNREFUSED**
Make sure the Next.js server is running on the correct port before launching the tunnel.
`./start.sh` handles this automatically.

**Cloudflare tunnel exits immediately**
Install cloudflared manually: https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/installation/
