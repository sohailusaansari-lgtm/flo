'use client';

import { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ImageStudio, VideoStudio, LipSyncStudio, CinemaStudio, MarketingStudio, WorkflowStudio, AgentStudio, AppsStudio } from 'studio';
import axios from 'axios';

const TABS = [
  { id: 'image',      label: 'Image Studio' },
  { id: 'video',      label: 'Video Studio' },
  { id: 'lipsync',    label: 'Lip Sync' },
  { id: 'cinema',     label: 'Cinema Studio' },
  { id: 'marketing',  label: 'Marketing Studio' },
  { id: 'workflows',  label: 'Workflows' },
  { id: 'agents',     label: 'Agents' },
  { id: 'apps',       label: 'Explore Apps' },
];

// API key is supplied via NEXT_PUBLIC_MUAPI_KEY environment variable.
// Set it in your .env.local file. No UI prompt required.
const ENV_API_KEY = process.env.NEXT_PUBLIC_MUAPI_KEY || '';

export default function StandaloneShell() {
  const params  = useParams();
  const router  = useRouter();
  const slug    = params?.slug || [];
  const idFromParams  = params?.id;
  const tabFromParams = params?.tab;

  const getWorkflowInfo = useCallback(() => {
    if (idFromParams) return { id: idFromParams, tab: tabFromParams || null };
    const wfIndex = slug.findIndex(s => s === 'workflows' || s === 'workflow');
    if (wfIndex === -1) return { id: null, tab: null };
    return { id: slug[wfIndex + 1] || null, tab: slug[wfIndex + 2] || null };
  }, [slug, idFromParams, tabFromParams]);

  const { id: urlWorkflowId } = getWorkflowInfo();

  const getInitialTab = () => {
    if (idFromParams || slug.includes('workflow')) return 'workflows';
    if (slug.includes('agents')) return 'agents';
    if (slug.includes('apps'))   return 'apps';
    const first = slug[0];
    if (first && TABS.find(t => t.id === first)) return first;
    return 'image';
  };

  const [activeTab,        setActiveTab]        = useState(getInitialTab());
  const [isHeaderVisible,  setIsHeaderVisible]  = useState(true);
  const [hasMounted,       setHasMounted]       = useState(false);
  const [isDragging,       setIsDragging]       = useState(false);
  const [droppedFiles,     setDroppedFiles]     = useState(null);

  useEffect(() => {
    const info = getWorkflowInfo();
    if (info.id)                    setActiveTab('workflows');
    else if (slug.includes('agents')) setActiveTab('agents');
    else if (slug.includes('apps'))   setActiveTab('apps');
    else {
      const first = slug[0];
      if (first && TABS.find(t => t.id === first)) setActiveTab(first);
    }
  }, [slug, getWorkflowInfo]);

  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    router.push(`/studio/${tabId}`);
  };

  useEffect(() => {
    const isEditingWorkflow = (activeTab === 'workflows' || !!idFromParams) && urlWorkflowId;
    setIsHeaderVisible(!isEditingWorkflow);
  }, [activeTab, urlWorkflowId, idFromParams]);

  useEffect(() => {
    const fromBuilder = sessionStorage.getItem('fromWorkflowBuilder');
    if (fromBuilder && activeTab !== 'workflows') {
      sessionStorage.removeItem('fromWorkflowBuilder');
      window.location.reload();
    }
  }, [activeTab]);

  // Inject API key into all proxied Axios requests
  useEffect(() => {
    delete axios.defaults.headers.common['x-api-key'];
    if (!ENV_API_KEY) return;
    const id = axios.interceptors.request.use((config) => {
      const isRelative = config.url.startsWith('/') || !config.url.startsWith('http');
      const isProxy    = ['/api/app', '/api/workflow', '/api/agents', '/api/api', '/api/v1']
                           .some(p => config.url.includes(p));
      if (isRelative || isProxy) config.headers['x-api-key'] = ENV_API_KEY;
      return config;
    });
    return () => axios.interceptors.request.eject(id);
  }, []);

  useEffect(() => {
    setHasMounted(true);
    if (ENV_API_KEY) {
      document.cookie = `muapi_key=${ENV_API_KEY}; path=/; max-age=31536000; SameSite=Lax`;
    }
  }, []);

  const handleDragOver  = useCallback((e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }, []);
  const handleDragEnter = useCallback((e) => { e.preventDefault(); setIsDragging(true); }, []);
  const handleDragLeave = useCallback((e) => { if (!e.currentTarget.contains(e.relatedTarget)) setIsDragging(false); }, []);
  const handleDrop      = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) setDroppedFiles(files);
  }, []);
  const handleFilesHandled = useCallback(() => setDroppedFiles(null), []);

  if (!hasMounted) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="animate-spin text-[#d9ff00] text-3xl">◌</div>
      </div>
    );
  }

  return (
    <div
      className="h-screen bg-[#030303] flex flex-col overflow-hidden text-white relative"
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {isDragging && (
        <div className="fixed inset-0 z-[100] bg-[#d9ff00]/10 backdrop-blur-md border-4 border-dashed border-[#d9ff00]/50 flex items-center justify-center pointer-events-none transition-all duration-300">
          <div className="bg-[#0a0a0a] p-8 rounded-3xl border border-white/10 shadow-2xl flex flex-col items-center gap-4 scale-110 animate-pulse">
            <div className="w-20 h-20 bg-[#d9ff00] rounded-2xl flex items-center justify-center">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="black" strokeWidth="2.5">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
              </svg>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-xl font-bold text-white">Drop your media here</span>
              <span className="text-sm text-white/40">Images, videos, or audio files</span>
            </div>
          </div>
        </div>
      )}

      {isHeaderVisible && (
        <header className="flex-shrink-0 h-14 border-b border-white/[0.03] flex items-center justify-between px-6 bg-black/20 backdrop-blur-md z-40">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="black" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
              </svg>
            </div>
            <span className="text-sm font-bold tracking-tight hidden sm:block">OpenGenerativeAI</span>
          </div>

          <nav className="absolute left-1/2 -translate-x-1/2 flex items-center gap-6">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={`relative py-4 text-[13px] font-medium transition-all whitespace-nowrap px-1 ${
                  activeTab === tab.id ? 'text-[#d9ff00]' : 'text-white/50 hover:text-white'
                }`}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#d9ff00] rounded-full" />
                )}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-3 bg-white/5 px-3 py-1.5 rounded-full border border-white/5">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs font-bold text-white/90">Ready</span>
          </div>
        </header>
      )}

      <div className="flex-1 min-h-0 relative overflow-hidden">
        {activeTab === 'image'     && <ImageStudio     apiKey={ENV_API_KEY} droppedFiles={droppedFiles} onFilesHandled={handleFilesHandled} />}
        {activeTab === 'video'     && <VideoStudio     apiKey={ENV_API_KEY} droppedFiles={droppedFiles} onFilesHandled={handleFilesHandled} />}
        {activeTab === 'lipsync'   && <LipSyncStudio   apiKey={ENV_API_KEY} droppedFiles={droppedFiles} onFilesHandled={handleFilesHandled} />}
        {activeTab === 'cinema'    && <CinemaStudio    apiKey={ENV_API_KEY} />}
        {activeTab === 'marketing' && <MarketingStudio apiKey={ENV_API_KEY} droppedFiles={droppedFiles} onFilesHandled={handleFilesHandled} />}
        {activeTab === 'workflows' && <WorkflowStudio  apiKey={ENV_API_KEY} isHeaderVisible={isHeaderVisible} onToggleHeader={setIsHeaderVisible} />}
        {activeTab === 'agents'    && <AgentStudio     apiKey={ENV_API_KEY} isHeaderVisible={isHeaderVisible} onToggleHeader={setIsHeaderVisible} />}
        {activeTab === 'apps'      && <AppsStudio      apiKey={ENV_API_KEY} />}
      </div>
    </div>
  );
}
