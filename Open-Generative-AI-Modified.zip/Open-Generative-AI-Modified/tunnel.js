#!/usr/bin/env node
/**
 * tunnel.js — Public tunnel launcher for Open Generative AI
 *
 * Priority:
 *   1. ngrok (fast, reliable, official npm package)
 *   2. Cloudflare Tunnel / cloudflared (fallback)
 *
 * Usage:
 *   node tunnel.js [port]         # default port = 3000
 *
 * Environment variables (from .env.local):
 *   NGROK_AUTHTOKEN    — ngrok auth token (optional but recommended)
 *   CF_TUNNEL_TOKEN    — Cloudflare tunnel token (fallback)
 *   PORT               — override default port
 */

'use strict';

const { spawn, execSync } = require('child_process');
const fs   = require('fs');
const path = require('path');
const http = require('http');

// ── Load .env.local ─────────────────────────────────────────────────────────
function loadEnv() {
  const envPath = path.join(__dirname, '.env.local');
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, 'utf8').split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) continue;
    const key = trimmed.slice(0, eqIdx).trim();
    const val = trimmed.slice(eqIdx + 1).trim().replace(/^["']|["']$/g, '');
    if (!process.env[key]) process.env[key] = val;
  }
}

loadEnv();

const PORT           = parseInt(process.env.PORT || process.argv[2] || '3000', 10);
const NGROK_TOKEN    = process.env.NGROK_AUTHTOKEN || '';
const CF_TOKEN       = process.env.CF_TUNNEL_TOKEN || '';

// ── Colour helpers ───────────────────────────────────────────────────────────
const c = {
  reset:  '\x1b[0m',
  green:  '\x1b[32m',
  yellow: '\x1b[33m',
  cyan:   '\x1b[36m',
  red:    '\x1b[31m',
  bold:   '\x1b[1m',
};

function log(msg)   { console.log(`${c.cyan}[tunnel]${c.reset} ${msg}`); }
function ok(msg)    { console.log(`${c.green}${c.bold}[tunnel]${c.reset} ${msg}`); }
function warn(msg)  { console.log(`${c.yellow}[tunnel]${c.reset} ${msg}`); }
function err(msg)   { console.error(`${c.red}[tunnel] ERROR:${c.reset} ${msg}`); }

// ── Wait for the local server to be ready ────────────────────────────────────
function waitForServer(port, maxMs = 60_000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const check = () => {
      const req = http.request({ host: '127.0.0.1', port, path: '/' }, () => resolve());
      req.on('error', () => {
        if (Date.now() - start > maxMs) return reject(new Error('Server did not start in time'));
        setTimeout(check, 1000);
      });
      req.end();
    };
    check();
  });
}

// ── ngrok tunnel ─────────────────────────────────────────────────────────────
async function tryNgrok() {
  try {
    // Check if @ngrok/ngrok is installed
    require.resolve('@ngrok/ngrok');
  } catch {
    log('Installing @ngrok/ngrok ...');
    try {
      execSync('npm install @ngrok/ngrok --save-dev', { stdio: 'inherit', cwd: __dirname });
    } catch {
      warn('@ngrok/ngrok install failed — will try Cloudflare next.');
      return null;
    }
  }

  const ngrok = require('@ngrok/ngrok');

  try {
    if (NGROK_TOKEN) {
      await ngrok.authtoken(NGROK_TOKEN);
    }
    log(`Connecting ngrok to port ${PORT} …`);
    const listener = await ngrok.forward({ addr: PORT, authtoken: NGROK_TOKEN || undefined });
    const url = listener.url();
    ok(`✅  ngrok tunnel active: ${c.bold}${url}${c.reset}`);
    printBox(url, 'ngrok');
    return url;
  } catch (e) {
    warn(`ngrok failed: ${e.message}`);
    return null;
  }
}

// ── Cloudflare Tunnel (cloudflared) ──────────────────────────────────────────
async function tryCloudflare() {
  // Determine binary path
  let cfBin = 'cloudflared';
  const localBin = path.join(__dirname, 'node_modules', '.bin', 'cloudflared');
  if (fs.existsSync(localBin)) cfBin = localBin;

  // Check if cloudflared is available
  try {
    execSync(`${cfBin} version`, { stdio: 'ignore' });
  } catch {
    log('Installing cloudflared via npm …');
    try {
      execSync('npm install cloudflared --save-dev', { stdio: 'inherit', cwd: __dirname });
      cfBin = localBin;
    } catch {
      // Try system-level install instructions
      warn('cloudflared not available. Install it manually: https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/');
      return null;
    }
  }

  return new Promise((resolve) => {
    const args = CF_TOKEN
      ? ['tunnel', '--no-autoupdate', 'run', '--token', CF_TOKEN]
      : ['tunnel', '--no-autoupdate', '--url', `http://localhost:${PORT}`];

    log(`Starting cloudflared (${CF_TOKEN ? 'named tunnel' : 'quick tunnel'}) …`);
    const proc = spawn(cfBin, args, { stdio: ['ignore', 'pipe', 'pipe'] });

    let url = null;
    const urlRegex = /https:\/\/[a-z0-9-]+\.trycloudflare\.com|https:\/\/[^\s]+\.cfargotunnel\.com/i;

    const handleData = (data) => {
      const text = data.toString();
      const match = text.match(urlRegex);
      if (match && !url) {
        url = match[0];
        ok(`✅  Cloudflare tunnel active: ${c.bold}${url}${c.reset}`);
        printBox(url, 'Cloudflare');
        resolve(url);
      }
    };

    proc.stdout.on('data', handleData);
    proc.stderr.on('data', handleData);

    proc.on('exit', (code) => {
      if (!url) {
        warn(`cloudflared exited with code ${code} before providing a URL.`);
        resolve(null);
      }
    });

    // Give cloudflared 30 s to provide a URL
    setTimeout(() => {
      if (!url) {
        warn('cloudflared did not provide a URL within 30 s.');
        proc.kill();
        resolve(null);
      }
    }, 30_000);
  });
}

// ── Pretty box ───────────────────────────────────────────────────────────────
function printBox(url, provider) {
  const line  = '─'.repeat(url.length + 4);
  console.log(`\n${c.green}${c.bold}┌${line}┐`);
  console.log(`│  🌐  ${url}  │`);
  console.log(`└${line}┘${c.reset}\n`);
  console.log(`  Provider  : ${provider}`);
  console.log(`  Local app : http://localhost:${PORT}`);
  console.log(`\n  Share the URL above to access the app from anywhere.\n`);
}

// ── Main ─────────────────────────────────────────────────────────────────────
async function main() {
  log(`Waiting for Next.js on port ${PORT} …`);
  try {
    await waitForServer(PORT);
    log('Server is ready — launching tunnel.');
  } catch (e) {
    warn('Could not confirm server is up — proceeding anyway.');
  }

  let url = await tryNgrok();
  if (!url) {
    log('Falling back to Cloudflare Tunnel …');
    url = await tryCloudflare();
  }

  if (!url) {
    err('Neither ngrok nor Cloudflare Tunnel could be started.');
    err('Make sure you have an internet connection and try again.');
    err('You can also run tunnels manually:');
    err(`  ngrok http ${PORT}`);
    err(`  cloudflared tunnel --url http://localhost:${PORT}`);
    process.exit(1);
  }

  // Keep the process alive so the tunnel stays open
  process.on('SIGINT',  () => { log('Shutting down tunnel …'); process.exit(0); });
  process.on('SIGTERM', () => { log('Shutting down tunnel …'); process.exit(0); });
}

main().catch((e) => { err(e.message); process.exit(1); });
