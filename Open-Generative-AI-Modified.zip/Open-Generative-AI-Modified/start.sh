#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# start.sh — One-command launcher for Open Generative AI
#
# Usage:
#   ./start.sh               # dev mode + tunnel
#   ./start.sh --prod        # production build + tunnel
#   ./start.sh --no-tunnel   # dev mode, local only
# ──────────────────────────────────────────────────────────────────────────────
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Load .env.local if present
if [ -f .env.local ]; then
  export $(grep -v '^#' .env.local | grep -v '^$' | xargs) 2>/dev/null || true
fi

PORT="${PORT:-3000}"
PROD=false
TUNNEL=true

for arg in "$@"; do
  case $arg in
    --prod)       PROD=true  ;;
    --no-tunnel)  TUNNEL=false ;;
  esac
done

# ── Colour helpers ─────────────────────────────────────────────────────────────
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[0;33m'
BOLD='\033[1m'
RESET='\033[0m'

log()  { echo -e "${CYAN}[start]${RESET} $1"; }
ok()   { echo -e "${GREEN}${BOLD}[start]${RESET} $1"; }
warn() { echo -e "${YELLOW}[start]${RESET} $1"; }

# ── Dependency check ───────────────────────────────────────────────────────────
if ! command -v node &>/dev/null; then
  echo "Node.js is required. Install it from https://nodejs.org" && exit 1
fi

NODE_VER=$(node -e "process.stdout.write(process.version.slice(1).split('.')[0])")
if [ "$NODE_VER" -lt 18 ]; then
  echo "Node.js 18+ required (found v$NODE_VER)." && exit 1
fi

# ── Install dependencies ───────────────────────────────────────────────────────
if [ ! -d node_modules ]; then
  log "Running npm install …"
  npm install
fi

# ── Build packages if needed ───────────────────────────────────────────────────
if [ ! -d packages/studio/dist ] && [ -f packages/studio/package.json ]; then
  log "Building studio package …"
  npm run build:packages 2>/dev/null || warn "Package build skipped (submodules may be empty)"
fi

# ── Start the Next.js server ───────────────────────────────────────────────────
if $PROD; then
  log "Building for production …"
  npm run build
  log "Starting production server on port $PORT …"
  PORT=$PORT npm run start &
else
  log "Starting dev server on port $PORT …"
  PORT=$PORT npm run dev &
fi

NEXT_PID=$!
log "Next.js PID: $NEXT_PID"

# ── Wait for server ────────────────────────────────────────────────────────────
log "Waiting for server to be ready …"
for i in $(seq 1 60); do
  if curl -s -o /dev/null "http://localhost:$PORT"; then
    ok "Server ready at http://localhost:$PORT"
    break
  fi
  sleep 1
done

# ── Launch tunnel ──────────────────────────────────────────────────────────────
if $TUNNEL; then
  log "Launching public tunnel …"
  node tunnel.js $PORT &
  TUNNEL_PID=$!
fi

ok "🚀  Open Generative AI is running!"
echo ""
echo "  Local  : http://localhost:$PORT"
$TUNNEL && echo "  Public : (see tunnel output above)"
echo ""
echo "  Press Ctrl+C to stop everything."

# ── Graceful shutdown ──────────────────────────────────────────────────────────
cleanup() {
  echo ""
  log "Shutting down …"
  kill $NEXT_PID 2>/dev/null || true
  $TUNNEL && kill $TUNNEL_PID 2>/dev/null || true
  exit 0
}
trap cleanup SIGINT SIGTERM

wait
