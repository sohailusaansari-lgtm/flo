"""
youtube_uploader.py - Upload videos to YouTube as Shorts
"""

import os
import time
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


def upload_to_youtube(
    video_path,
    title,
    description,
    tags,
    thumbnail_path=None,
    category_id="27",  # 27 = Education
    privacy="public"
):
    """
    Upload video to YouTube as Shorts
    Returns: video_id or None
    """
    try:
        from auth import get_youtube_service
        from googleapiclient.http import MediaFileUpload

        service = get_youtube_service()

        # Ensure #Shorts in title/description for YouTube Shorts algorithm
        if "#Shorts" not in title and "#shorts" not in title:
            short_title = f"{title} #Shorts"
        else:
            short_title = title

        if "#Shorts" not in description and "#shorts" not in description:
            description = f"{description}\n\n#Shorts #YouTubeShorts"

        body = {
            "snippet": {
                "title": short_title[:100],
                "description": description[:5000],
                "tags": tags[:500] if tags else [],
                "categoryId": category_id,
                "defaultLanguage": "en",
            },
            "status": {
                "privacyStatus": privacy,
                "selfDeclaredMadeForKids": False,
                "madeForKids": False,
            }
        }

        print(f"📤 Uploading to YouTube: {short_title[:60]}...")

        media = MediaFileUpload(
            str(video_path),
            mimetype="video/mp4",
            resumable=True,
            chunksize=1024 * 1024 * 5  # 5MB chunks
        )

        request = service.videos().insert(
            part="snippet,status",
            body=body,
            media_body=media
        )

        response = None
        retry = 0
        while response is None:
            try:
                status, response = request.next_chunk()
                if status:
                    pct = int(status.progress() * 100)
                    print(f"  Upload progress: {pct}%")
            except Exception as e:
                if retry < 3:
                    retry += 1
                    print(f"  ⚠️  Chunk error, retrying ({retry}/3)...")
                    time.sleep(5)
                else:
                    raise e

        video_id = response.get("id")
        print(f"✅ Uploaded! Video ID: {video_id}")
        print(f"   URL: https://www.youtube.com/shorts/{video_id}")

        # Upload thumbnail if provided
        if thumbnail_path and Path(thumbnail_path).exists() and video_id:
            try:
                thumb_media = MediaFileUpload(
                    str(thumbnail_path),
                    mimetype="image/jpeg"
                )
                service.thumbnails().set(
                    videoId=video_id,
                    media_body=thumb_media
                ).execute()
                print(f"✅ Thumbnail uploaded!")
            except Exception as e:
                print(f"⚠️  Thumbnail upload failed: {e}")

        return video_id

    except Exception as e:
        print(f"❌ YouTube upload failed: {e}")
        return None


def get_channel_info():
    """Get current channel info"""
    try:
        from auth import get_youtube_service
        service = get_youtube_service()
        response = service.channels().list(part="snippet,statistics", mine=True).execute()
        if response.get("items"):
            item = response["items"][0]
            return {
                "name": item["snippet"]["title"],
                "id": item["id"],
                "subscribers": item["statistics"].get("subscriberCount", "N/A"),
                "videos": item["statistics"].get("videoCount", "N/A"),
            }
    except Exception as e:
        print(f"⚠️  Could not get channel info: {e}")
    return None


def get_recent_uploads(max_results=5):
    """Get list of recent video uploads"""
    try:
        from auth import get_youtube_service
        service = get_youtube_service()

        # Get channel's uploads playlist
        ch_response = service.channels().list(
            part="contentDetails", mine=True
        ).execute()

        if not ch_response.get("items"):
            return []

        uploads_playlist = ch_response["items"][0]["contentDetails"]["relatedPlaylists"]["uploads"]

        # Get videos from playlist
        pl_response = service.playlistItems().list(
            part="snippet",
            playlistId=uploads_playlist,
            maxResults=max_results
        ).execute()

        videos = []
        for item in pl_response.get("items", []):
            snippet = item["snippet"]
            vid_id = snippet["resourceId"]["videoId"]
            videos.append({
                "title": snippet["title"],
                "id": vid_id,
                "url": f"https://youtube.com/shorts/{vid_id}",
                "published": snippet["publishedAt"],
            })

        return videos
    except Exception as e:
        print(f"⚠️  Could not get recent uploads: {e}")
        return []


if __name__ == "__main__":
    info = get_channel_info()
    if info:
        print(f"Channel: {info['name']}")
        print(f"Subscribers: {info['subscribers']}")
        print(f"Videos: {info['videos']}")
