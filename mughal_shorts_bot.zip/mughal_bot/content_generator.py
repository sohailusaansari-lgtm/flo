"""
content_generator.py - Gemini via direct REST API (no SDK needed)
Works on Termux without building wheels.
"""

import os
import json
import random
import requests
from dotenv import load_dotenv

load_dotenv()


def _call_gemini(prompt):
    """Call Gemini 1.5 Flash via REST — no SDK, just requests."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("GEMINI_API_KEY not set in .env")

    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-1.5-flash:generateContent?key={api_key}"
    )
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.9,
            "maxOutputTokens": 2048,
        }
    }
    resp = requests.post(url, json=payload, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    return data["candidates"][0]["content"]["parts"][0]["text"].strip()


TOPIC_POOL = [
    "Mughal Architecture Wonders",
    "Emperor Akbar's Golden Era",
    "Taj Mahal's Secret History",
    "Aurangzeb's Controversial Reign",
    "Mughal Cuisine and Royal Feasts",
    "Mughal Military Strategies",
    "Shah Jahan's Love Story",
    "Babur - Founder of Mughal Empire",
    "Humayun's Exile and Return",
    "Mughal Art and Miniature Paintings",
    "Depth of the Pacific Ocean",
    "Bioluminescent Ocean Creatures",
    "Mariana Trench Mysteries",
    "Ocean Currents and Climate",
    "Deep Sea Monsters - Real Facts",
    "The Bermuda Triangle Truth",
    "Coral Reef Ecosystems",
    "Whale Migration Secrets",
    "Ocean Floor Volcanoes",
    "Tides and Moon Connection",
    "Surah Al-Kahf Hidden Meanings",
    "Miracles in the Quran Proven by Science",
    "Prophet Muhammad's Life Lessons",
    "Islamic Golden Age Discoveries",
    "Quran and the Big Bang Theory",
    "Zamzam Water Scientific Facts",
    "Islamic Architecture Masterpieces",
    "The Night Journey Isra and Miraj",
    "Quran's Description of Embryology",
    "Islam's Contribution to Mathematics",
]


def get_random_topic(custom_topic=None):
    if custom_topic:
        return custom_topic
    return random.choice(TOPIC_POOL)


def generate_video_script(topic):
    """Generate full video script via Gemini REST API."""
    prompt = f"""Create a compelling YouTube Shorts video script about: "{topic}"

Requirements:
- Duration: 40-55 seconds when read aloud (approximately 110-145 words)
- Style: Educational, engaging, dramatic storytelling
- Hook viewer in first 3 seconds
- Include surprising facts
- End with a powerful conclusion

Return ONLY a valid JSON object (no markdown, no backticks) with this exact structure:
{{
  "title": "Catchy YouTube title under 100 chars with emojis",
  "description": "YouTube description 150-200 words with hashtags",
  "script": "Full narration script 110-145 words",
  "hook": "First sentence that grabs attention",
  "key_facts": ["fact1", "fact2", "fact3", "fact4", "fact5"],
  "image_search_queries": [
    "query1", "query2", "query3", "query4", "query5",
    "query6", "query7", "query8", "query9", "query10",
    "query11", "query12", "query13", "query14", "query15",
    "query16", "query17", "query18", "query19", "query20",
    "query21", "query22", "query23", "query24", "query25",
    "query26", "query27", "query28", "query29", "query30"
  ],
  "thumbnail_text": "Bold text for thumbnail max 5 words",
  "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"],
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5", "tag6", "tag7", "tag8"]
}}"""

    text = _call_gemini(prompt)

    # Strip markdown fences if present
    if "```" in text:
        parts = text.split("```")
        for part in parts:
            part = part.strip()
            if part.startswith("json"):
                part = part[4:].strip()
            if part.startswith("{"):
                text = part
                break

    data = json.loads(text)

    # Ensure 30 image queries
    queries = data.get("image_search_queries", [])
    extras = [
        f"{topic} history", f"{topic} facts", f"{topic} amazing",
        f"{topic} ancient", f"{topic} beautiful", f"{topic} stunning",
    ]
    while len(queries) < 30:
        queries.append(extras[len(queries) % len(extras)])
    data["image_search_queries"] = queries[:30]

    return data


def generate_subtitle_segments(script):
    """Split script into timed subtitle segments (~6 words each)."""
    words = script.split()
    segments = []
    words_per_seg = 6
    seconds_per_word = 1 / 2.5   # ~2.5 words/sec natural speech
    current_time = 0.0
    i = 0

    while i < len(words):
        chunk = words[i:i + words_per_seg]
        text = " ".join(chunk)
        duration = len(chunk) * seconds_per_word
        segments.append({
            "text": text,
            "start": round(current_time, 2),
            "end": round(current_time + duration, 2),
            "duration": round(duration, 2)
        })
        current_time += duration
        i += words_per_seg

    return segments


if __name__ == "__main__":
    print("Testing Gemini REST API...")
    topic = get_random_topic()
    print(f"Topic: {topic}")
    data = generate_video_script(topic)
    print(f"Title: {data['title']}")
    print(f"Script words: {len(data['script'].split())}")
    print(f"Image queries: {len(data['image_search_queries'])}")
    segs = generate_subtitle_segments(data["script"])
    print(f"Subtitle segments: {len(segs)}")
    print("✅ OK")
