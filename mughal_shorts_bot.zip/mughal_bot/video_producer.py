"""
video_producer.py - Assemble final YouTube Shorts video
Combines images + voice + subtitles into 40-55s vertical video
"""

import os
import sys
import math
import random
import subprocess
import tempfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from dotenv import load_dotenv

load_dotenv()

TARGET_W = 1080
TARGET_H = 1920
FPS = 30
MIN_DURATION = 40
MAX_DURATION = 55

FONT_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/system/fonts/Roboto-Bold.ttf",
    "/data/data/com.termux/files/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
]


def get_font(size):
    for path in FONT_PATHS:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            continue
    return ImageFont.load_default()


def draw_subtitle_on_frame(frame_img, text, position="bottom"):
    """Draw big bold subtitle text on a frame"""
    img = frame_img.copy()
    draw = ImageDraw.Draw(img)
    
    font_size = 72
    font = get_font(font_size)
    
    max_width = TARGET_W - 80
    
    # Word wrap
    words = text.split()
    lines = []
    current = []
    for word in words:
        test = " ".join(current + [word])
        bbox = draw.textbbox((0, 0), test, font=font)
        if bbox[2] - bbox[0] <= max_width:
            current.append(word)
        else:
            if current:
                lines.append(" ".join(current))
            current = [word]
    if current:
        lines.append(" ".join(current))
    
    line_h = font_size + 16
    total_h = len(lines) * line_h
    padding = 24
    box_h = total_h + padding * 2
    
    if position == "bottom":
        box_y = TARGET_H - box_h - 120
    else:
        box_y = TARGET_H // 2 - box_h // 2
    
    # Draw semi-transparent background
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ov_draw = ImageDraw.Draw(overlay)
    margin = 30
    ov_draw.rounded_rectangle(
        [(margin, box_y - 10), (TARGET_W - margin, box_y + box_h + 10)],
        radius=20,
        fill=(0, 0, 0, 175)
    )
    img_rgba = img.convert("RGBA")
    img_rgba = Image.alpha_composite(img_rgba, overlay)
    img = img_rgba.convert("RGB")
    draw = ImageDraw.Draw(img)
    
    # Draw text lines
    for i, line in enumerate(lines):
        bbox = draw.textbbox((0, 0), line, font=font)
        text_w = bbox[2] - bbox[0]
        x = (TARGET_W - text_w) // 2
        y = box_y + padding + i * line_h
        
        # Outline (black)
        for dx in [-3, -2, 2, 3]:
            for dy in [-3, -2, 2, 3]:
                draw.text((x + dx, y + dy), line, font=font, fill=(0, 0, 0))
        
        # Main text (bright white/yellow)
        draw.text((x, y), line, font=font, fill=(255, 245, 100))
    
    return img


def apply_zoom_effect(img, zoom_factor):
    """Apply Ken Burns zoom effect"""
    w, h = img.size
    crop_w = int(w / zoom_factor)
    crop_h = int(h / zoom_factor)
    left = (w - crop_w) // 2
    top = (h - crop_h) // 2
    cropped = img.crop((left, top, left + crop_w, top + crop_h))
    return cropped.resize((w, h), Image.LANCZOS)


def create_transition_frames(img1, img2, num_frames=15):
    """Create smooth crossfade transition frames"""
    frames = []
    for i in range(num_frames):
        alpha = i / num_frames
        blended = Image.blend(img1, img2, alpha)
        frames.append(blended)
    return frames


def build_video_with_ffmpeg(
    image_paths,
    audio_path,
    subtitle_segments,
    output_path,
    audio_duration
):
    """
    Build video using ffmpeg directly for best performance
    Each image is shown for equal time across the audio duration
    """
    work_dir = Path(output_path).parent / "ffmpeg_work"
    work_dir.mkdir(exist_ok=True)
    
    # Calculate timing
    num_images = len(image_paths)
    time_per_image = audio_duration / num_images
    
    # Generate frames with subtitles
    print(f"🎬 Generating {num_images} image segments ({time_per_image:.1f}s each)...")
    
    frame_list_file = work_dir / "frames.txt"
    processed_images = []
    
    for idx, img_path in enumerate(image_paths):
        try:
            img = Image.open(img_path).convert("RGB")
            img = img.resize((TARGET_W, TARGET_H), Image.LANCZOS)
        except Exception:
            img = Image.new("RGB", (TARGET_W, TARGET_H), (20, 20, 40))
        
        # Find subtitle for this time window
        img_start_time = idx * time_per_image
        img_end_time = img_start_time + time_per_image
        subtitle_text = ""
        
        for seg in subtitle_segments:
            if seg["start"] <= img_start_time < seg["end"]:
                subtitle_text = seg["text"]
                break
            elif img_start_time <= seg["start"] < img_end_time:
                subtitle_text = seg["text"]
                break
        
        if subtitle_text:
            img = draw_subtitle_on_frame(img, subtitle_text)
        
        # Apply slight zoom for dynamic effect
        zoom = 1.0 + (idx % 3) * 0.02
        if zoom > 1.0:
            img = apply_zoom_effect(img, zoom)
        
        frame_path = work_dir / f"frame_{idx:04d}.jpg"
        img.save(str(frame_path), "JPEG", quality=90)
        processed_images.append((str(frame_path), time_per_image))
    
    # Write ffmpeg concat file
    with open(frame_list_file, "w") as f:
        for frame_path, duration in processed_images:
            f.write(f"file '{frame_path}'\n")
            f.write(f"duration {duration:.3f}\n")
        # Repeat last frame
        f.write(f"file '{processed_images[-1][0]}'\n")
    
    # Build video from images
    temp_video = work_dir / "temp_video.mp4"
    cmd_video = [
        "ffmpeg", "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", str(frame_list_file),
        "-vf", f"scale={TARGET_W}:{TARGET_H}:force_original_aspect_ratio=decrease,pad={TARGET_W}:{TARGET_H}:(ow-iw)/2:(oh-ih)/2",
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "23",
        "-pix_fmt", "yuv420p",
        "-r", str(FPS),
        str(temp_video)
    ]
    
    print("🎬 Encoding video...")
    result = subprocess.run(cmd_video, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        print(f"❌ Video encoding error: {result.stderr[-500:]}")
        return False
    
    # Merge with audio
    print("🔊 Merging audio...")
    cmd_merge = [
        "ffmpeg", "-y",
        "-i", str(temp_video),
        "-i", str(audio_path),
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        "-map", "0:v:0",
        "-map", "1:a:0",
        str(output_path)
    ]
    
    result = subprocess.run(cmd_merge, capture_output=True, text=True, timeout=120)
    if result.returncode != 0:
        print(f"❌ Audio merge error: {result.stderr[-500:]}")
        return False
    
    print(f"✅ Video created: {output_path}")
    
    # Cleanup
    try:
        import shutil
        shutil.rmtree(str(work_dir))
    except Exception:
        pass
    
    return True


def add_intro_outro(video_path, topic, output_path):
    """Add subtle intro/outro cards"""
    # For now, just copy - can enhance later
    import shutil
    shutil.copy2(str(video_path), str(output_path))
    return True


def produce_video(
    image_paths,
    audio_path,
    subtitle_segments,
    output_dir,
    topic,
    audio_duration=None
):
    """
    Main video production function
    
    Returns: output video path or None
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Determine audio duration
    if audio_duration is None:
        from voice_generator import get_audio_duration
        audio_duration = get_audio_duration(audio_path)
        if audio_duration is None:
            audio_duration = 47  # Default
    
    # Clamp to 40-55 seconds
    audio_duration = max(MIN_DURATION, min(MAX_DURATION, audio_duration))
    
    print(f"🎬 Producing video: {audio_duration:.1f}s duration, {len(image_paths)} images")
    
    # Use exactly 30 images (repeat/trim as needed)
    target_img_count = 30
    if len(image_paths) < target_img_count:
        # Repeat images
        while len(image_paths) < target_img_count:
            image_paths = image_paths + image_paths
    image_paths = image_paths[:target_img_count]
    
    # Shuffle for variety
    random.shuffle(image_paths)
    
    raw_video = output_dir / "raw_video.mp4"
    
    success = build_video_with_ffmpeg(
        image_paths=image_paths,
        audio_path=audio_path,
        subtitle_segments=subtitle_segments,
        output_path=str(raw_video),
        audio_duration=audio_duration
    )
    
    if not success:
        return None
    
    final_video = output_dir / "final_video.mp4"
    add_intro_outro(str(raw_video), topic, str(final_video))
    
    # Clean raw
    try:
        raw_video.unlink()
    except Exception:
        pass
    
    return str(final_video)


if __name__ == "__main__":
    print("Video producer module loaded. Run main.py to start the bot.")
