"""
thumbnail_generator.py - Create attractive YouTube Shorts thumbnails
High-contrast, bold typography, cinematic style
"""

import os
import random
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
from dotenv import load_dotenv

load_dotenv()

THUMB_WIDTH = 1080
THUMB_HEIGHT = 1920

# Font paths (fallback chain)
FONT_PATHS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/system/fonts/Roboto-Bold.ttf",  # Android/Termux
    "/data/data/com.termux/files/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
]

THUMBNAIL_THEMES = [
    {
        "name": "golden_empire",
        "bg_colors": [(20, 10, 0), (80, 40, 0)],
        "accent": (255, 180, 0),
        "text_color": (255, 240, 200),
        "overlay_color": (120, 60, 0, 120),
    },
    {
        "name": "ocean_deep",
        "bg_colors": [(0, 10, 40), (0, 40, 80)],
        "accent": (0, 200, 255),
        "text_color": (200, 240, 255),
        "overlay_color": (0, 50, 100, 140),
    },
    {
        "name": "islamic_green",
        "bg_colors": [(0, 30, 10), (0, 80, 30)],
        "accent": (50, 220, 100),
        "text_color": (220, 255, 230),
        "overlay_color": (0, 80, 30, 130),
    },
    {
        "name": "dramatic_red",
        "bg_colors": [(40, 0, 0), (100, 10, 10)],
        "accent": (255, 60, 0),
        "text_color": (255, 220, 210),
        "overlay_color": (120, 20, 0, 120),
    },
    {
        "name": "royal_purple",
        "bg_colors": [(20, 0, 40), (60, 0, 100)],
        "accent": (180, 100, 255),
        "text_color": (230, 210, 255),
        "overlay_color": (60, 0, 100, 140),
    },
]


def get_font(size):
    """Load best available bold font"""
    for path in FONT_PATHS:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            continue
    return ImageFont.load_default()


def create_gradient_background(width, height, color1, color2):
    """Create vertical gradient background"""
    img = Image.new("RGB", (width, height))
    for y in range(height):
        factor = y / height
        r = int(color1[0] + (color2[0] - color1[0]) * factor)
        g = int(color1[1] + (color2[1] - color1[1]) * factor)
        b = int(color1[2] + (color2[2] - color1[2]) * factor)
        for x in range(width):
            img.putpixel((x, y), (r, g, b))
    return img


def draw_decorative_lines(draw, width, height, color):
    """Draw geometric decorative elements"""
    # Horizontal accent lines
    for i in range(3):
        y = height // 4 + i * (height // 4)
        opacity = [255, 180, 100][i]
        draw.line([(50, y), (width - 50, y)],
                  fill=(*color[:3], opacity), width=2)
    
    # Corner decorations
    corner_size = 80
    lw = 4
    corners = [
        (30, 30, 30 + corner_size, 30, 30, 30 + corner_size),  # Top-left
        (width - 30 - corner_size, 30, width - 30, 30, width - 30, 30 + corner_size),  # Top-right
        (30, height - 30 - corner_size, 30, height - 30, 30 + corner_size, height - 30),  # Bottom-left
        (width - 30 - corner_size, height - 30, width - 30, height - 30, width - 30, height - 30 - corner_size),  # Bottom-right
    ]
    for pts in corners:
        draw.line([pts[0], pts[1], pts[2], pts[3]], fill=color, width=lw)
        draw.line([pts[4], pts[5], pts[2], pts[3]], fill=color, width=lw)


def wrap_text(text, font, max_width, draw):
    """Wrap text to fit max_width"""
    words = text.upper().split()
    lines = []
    current_line = []
    
    for word in words:
        test_line = " ".join(current_line + [word])
        bbox = draw.textbbox((0, 0), test_line, font=font)
        w = bbox[2] - bbox[0]
        if w <= max_width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(" ".join(current_line))
            current_line = [word]
    
    if current_line:
        lines.append(" ".join(current_line))
    
    return lines


def draw_text_with_shadow(draw, text, position, font, fill, shadow_color=(0, 0, 0), shadow_offset=4):
    """Draw text with drop shadow"""
    x, y = position
    # Shadow
    draw.text((x + shadow_offset, y + shadow_offset), text, font=font, fill=shadow_color)
    # Outline
    for dx in [-2, 2]:
        for dy in [-2, 2]:
            draw.text((x + dx, y + dy), text, font=font, fill=(0, 0, 0))
    # Main text
    draw.text((x, y), text, font=font, fill=fill)


def create_thumbnail(
    text,
    output_path,
    background_image_path=None,
    theme=None,
    subtitle=None
):
    """
    Create an attractive YouTube Shorts thumbnail
    
    Args:
        text: Main bold text (max 5 words)
        output_path: Where to save thumbnail
        background_image_path: Optional background image
        theme: Color theme dict or None for random
        subtitle: Optional subtitle line
    """
    if theme is None:
        theme = random.choice(THUMBNAIL_THEMES)
    
    # Start with background
    if background_image_path and Path(background_image_path).exists():
        bg = Image.open(background_image_path).convert("RGB")
        # Resize to thumbnail size
        bg = bg.resize((THUMB_WIDTH, THUMB_HEIGHT), Image.LANCZOS)
        # Darken for text readability
        enhancer = ImageEnhance.Brightness(bg)
        bg = enhancer.enhance(0.45)
        enhancer = ImageEnhance.Contrast(bg)
        bg = enhancer.enhance(1.3)
    else:
        bg = create_gradient_background(
            THUMB_WIDTH, THUMB_HEIGHT,
            theme["bg_colors"][0],
            theme["bg_colors"][1]
        )
    
    # Add color overlay for drama
    overlay = Image.new("RGBA", (THUMB_WIDTH, THUMB_HEIGHT),
                        theme.get("overlay_color", (0, 0, 0, 100)))
    bg_rgba = bg.convert("RGBA")
    bg_rgba = Image.alpha_composite(bg_rgba, overlay)
    bg = bg_rgba.convert("RGB")
    
    # Add blur to bottom for text area
    bottom_strip = bg.crop((0, THUMB_HEIGHT - 700, THUMB_WIDTH, THUMB_HEIGHT))
    bottom_strip = bottom_strip.filter(ImageFilter.GaussianBlur(radius=15))
    bg.paste(bottom_strip, (0, THUMB_HEIGHT - 700))
    
    draw = ImageDraw.Draw(bg)
    
    # Draw decorative elements
    draw_decorative_lines(draw, THUMB_WIDTH, THUMB_HEIGHT, theme["accent"])
    
    # === MAIN TITLE TEXT ===
    title_font_size = 130
    title_font = get_font(title_font_size)
    
    padding = 60
    max_text_width = THUMB_WIDTH - padding * 2
    
    lines = wrap_text(text, title_font, max_text_width, draw)
    
    # Adjust font size if too many lines
    while len(lines) > 4 and title_font_size > 70:
        title_font_size -= 10
        title_font = get_font(title_font_size)
        lines = wrap_text(text, title_font, max_text_width, draw)
    
    # Calculate text block height
    line_height = title_font_size + 20
    total_text_height = len(lines) * line_height
    
    # Position text in lower 40% of image
    text_start_y = THUMB_HEIGHT - total_text_height - 200
    if subtitle:
        text_start_y -= 80
    
    # Draw each line centered
    for i, line in enumerate(lines):
        bbox = draw.textbbox((0, 0), line, font=title_font)
        text_w = bbox[2] - bbox[0]
        x = (THUMB_WIDTH - text_w) // 2
        y = text_start_y + i * line_height
        
        draw_text_with_shadow(draw, line, (x, y), title_font,
                              fill=theme["text_color"],
                              shadow_color=(0, 0, 0),
                              shadow_offset=5)
    
    # === ACCENT BAR ===
    bar_y = text_start_y - 20
    bar_height = 6
    bar_margin = 100
    draw.rectangle(
        [(bar_margin, bar_y), (THUMB_WIDTH - bar_margin, bar_y + bar_height)],
        fill=theme["accent"]
    )
    
    # === SUBTITLE ===
    if subtitle:
        sub_font = get_font(55)
        sub_y = text_start_y + total_text_height + 20
        sub_text = subtitle.upper()
        bbox = draw.textbbox((0, 0), sub_text, font=sub_font)
        sub_w = bbox[2] - bbox[0]
        sub_x = (THUMB_WIDTH - sub_w) // 2
        draw_text_with_shadow(draw, sub_text, (sub_x, sub_y), sub_font,
                              fill=theme["accent"],
                              shadow_color=(0, 0, 0),
                              shadow_offset=3)
    
    # === TOP BADGE ===
    badge_text = "🔥 FACTS"
    badge_font = get_font(50)
    badge_bg = Image.new("RGBA", (280, 80), (*theme["accent"][:3], 220))
    bg_rgba2 = bg.convert("RGBA")
    bg_rgba2.paste(badge_bg, (60, 60), badge_bg)
    bg = bg_rgba2.convert("RGB")
    draw = ImageDraw.Draw(bg)
    draw.text((80, 75), badge_text, font=badge_font, fill=(0, 0, 0))
    
    # Save
    bg.save(str(output_path), "JPEG", quality=95)
    print(f"✅ Thumbnail saved: {output_path}")
    return str(output_path)


if __name__ == "__main__":
    create_thumbnail(
        "SECRET MUGHAL HISTORY",
        "/tmp/test_thumbnail.jpg",
        subtitle="You Won't Believe This"
    )
    print("Thumbnail created!")
