"""
image_fetcher.py - Fetch and process images from Unsplash/Pexels
Downloads 30+ images for video production
"""

import os
import requests
import random
import hashlib
from pathlib import Path
from PIL import Image, ImageFilter, ImageEnhance
from io import BytesIO
from dotenv import load_dotenv

load_dotenv()

UNSPLASH_KEY = os.getenv("UNSPLASH_ACCESS_KEY")
PEXELS_KEY = os.getenv("PEXELS_API_KEY")

# Target dimensions for YouTube Shorts (9:16)
TARGET_WIDTH = 1080
TARGET_HEIGHT = 1920


def fetch_unsplash_images(query, count=5):
    """Fetch images from Unsplash"""
    if not UNSPLASH_KEY:
        return []
    
    images = []
    try:
        url = "https://api.unsplash.com/search/photos"
        params = {
            "query": query,
            "per_page": min(count, 30),
            "orientation": "portrait",
            "client_id": UNSPLASH_KEY
        }
        response = requests.get(url, params=params, timeout=10)
        data = response.json()
        
        for item in data.get("results", []):
            img_url = item["urls"].get("regular") or item["urls"].get("full")
            if img_url:
                images.append({
                    "url": img_url,
                    "source": "unsplash",
                    "description": item.get("description") or item.get("alt_description", "")
                })
    except Exception as e:
        print(f"⚠️  Unsplash error for '{query}': {e}")
    
    return images


def fetch_pexels_images(query, count=5):
    """Fetch images from Pexels"""
    if not PEXELS_KEY:
        return []
    
    images = []
    try:
        url = "https://api.pexels.com/v1/search"
        headers = {"Authorization": PEXELS_KEY}
        params = {
            "query": query,
            "per_page": min(count, 30),
            "orientation": "portrait"
        }
        response = requests.get(url, headers=headers, params=params, timeout=10)
        data = response.json()
        
        for item in data.get("photos", []):
            img_url = item["src"].get("large2x") or item["src"].get("large")
            if img_url:
                images.append({
                    "url": img_url,
                    "source": "pexels",
                    "description": item.get("alt", "")
                })
    except Exception as e:
        print(f"⚠️  Pexels error for '{query}': {e}")
    
    return images


def download_image(url, save_path):
    """Download image from URL"""
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        response = requests.get(url, headers=headers, timeout=15, stream=True)
        response.raise_for_status()
        
        img = Image.open(BytesIO(response.content))
        if img.mode != "RGB":
            img = img.convert("RGB")
        
        img.save(save_path, "JPEG", quality=95)
        return True
    except Exception as e:
        print(f"⚠️  Download failed for {url}: {e}")
        return False


def process_image_for_shorts(input_path, output_path, effect=None):
    """
    Process image to 9:16 format (1080x1920) for YouTube Shorts
    Apply cinematic effects
    """
    try:
        img = Image.open(input_path).convert("RGB")
        orig_w, orig_h = img.size
        
        # Scale to fill 1080x1920 (crop center)
        scale_w = TARGET_WIDTH / orig_w
        scale_h = TARGET_HEIGHT / orig_h
        scale = max(scale_w, scale_h)
        
        new_w = int(orig_w * scale)
        new_h = int(orig_h * scale)
        img = img.resize((new_w, new_h), Image.LANCZOS)
        
        # Center crop
        left = (new_w - TARGET_WIDTH) // 2
        top = (new_h - TARGET_HEIGHT) // 2
        img = img.crop((left, top, left + TARGET_WIDTH, top + TARGET_HEIGHT))
        
        # Apply cinematic effects
        if effect == "dramatic":
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(1.3)
            enhancer = ImageEnhance.Color(img)
            img = enhancer.enhance(0.85)
        elif effect == "warm":
            enhancer = ImageEnhance.Color(img)
            img = enhancer.enhance(1.2)
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(1.05)
        elif effect == "cinematic":
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(1.15)
            enhancer = ImageEnhance.Sharpness(img)
            img = enhancer.enhance(1.1)
        
        # Add subtle vignette (darken edges)
        img = add_vignette(img)
        
        img.save(output_path, "JPEG", quality=95)
        return True
    except Exception as e:
        print(f"⚠️  Process error: {e}")
        return False


def add_vignette(img):
    """Add subtle vignette effect"""
    from PIL import ImageDraw
    import numpy as np
    
    w, h = img.size
    vignette = Image.new("L", (w, h), 255)
    draw = ImageDraw.Draw(vignette)
    
    # Create radial gradient (brighter center, darker edges)
    for i in range(min(w, h) // 2, 0, -1):
        alpha = int(255 * (i / (min(w, h) // 2)) ** 0.5)
        draw.ellipse([w//2-i, h//2-i, w//2+i, h//2+i], fill=alpha)
    
    vignette = vignette.filter(ImageFilter.GaussianBlur(radius=50))
    
    # Blend vignette
    img_array = img.copy()
    vignette_rgb = vignette.convert("RGB")
    blended = Image.blend(img, vignette_rgb, 0.0)  # keep original, just concept
    
    return img  # Return original for now (full vignette needs numpy)


def create_fallback_image(output_path, text="", color=(20, 20, 40)):
    """Create a colored fallback image when download fails"""
    from PIL import ImageDraw, ImageFont
    
    img = Image.new("RGB", (TARGET_WIDTH, TARGET_HEIGHT), color)
    
    # Add gradient
    for y in range(TARGET_HEIGHT):
        factor = y / TARGET_HEIGHT
        r = int(color[0] * (1 - factor * 0.5))
        g = int(color[1] * (1 - factor * 0.5))
        b = int(color[2] + (255 - color[2]) * factor * 0.1)
        for x in range(TARGET_WIDTH):
            img.putpixel((x, y), (r, g, b))
    
    if text:
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 60)
        except Exception:
            font = ImageFont.load_default()
        
        words = text.split()
        lines = []
        current = []
        for word in words:
            current.append(word)
            if len(" ".join(current)) > 20:
                lines.append(" ".join(current[:-1]))
                current = [word]
        if current:
            lines.append(" ".join(current))
        
        y_pos = TARGET_HEIGHT // 2 - len(lines) * 40
        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=font)
            tw = bbox[2] - bbox[0]
            draw.text(((TARGET_WIDTH - tw) // 2, y_pos), line, fill=(255, 255, 255), font=font)
            y_pos += 80
    
    img.save(output_path, "JPEG", quality=95)
    return True


def fetch_all_images(queries, output_dir, target_count=30, notify_callback=None):
    """
    Fetch images for all queries, ensuring we hit target_count
    Returns list of processed image paths
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    raw_dir = output_dir / "raw"
    raw_dir.mkdir(exist_ok=True)
    
    processed_paths = []
    all_image_urls = []
    
    effects = ["dramatic", "warm", "cinematic", None, "dramatic", "warm"]
    
    print(f"🖼️  Fetching images for {len(queries)} queries...")
    
    # Collect URLs from all sources
    for i, query in enumerate(queries):
        if notify_callback:
            notify_callback(f"Fetching images: {i+1}/{len(queries)}")
        
        # Try Unsplash first
        unsplash_imgs = fetch_unsplash_images(query, count=2)
        all_image_urls.extend(unsplash_imgs)
        
        # Try Pexels
        pexels_imgs = fetch_pexels_images(query, count=2)
        all_image_urls.extend(pexels_imgs)
        
        # Break if we have more than enough
        if len(all_image_urls) >= target_count * 2:
            break
    
    # Remove duplicates by URL
    seen_urls = set()
    unique_images = []
    for img in all_image_urls:
        if img["url"] not in seen_urls:
            seen_urls.add(img["url"])
            unique_images.append(img)
    
    # Download and process
    downloaded = 0
    for idx, img_data in enumerate(unique_images):
        if downloaded >= target_count:
            break
        
        url_hash = hashlib.md5(img_data["url"].encode()).hexdigest()[:8]
        raw_path = raw_dir / f"raw_{idx:03d}_{url_hash}.jpg"
        proc_path = output_dir / f"img_{downloaded:03d}.jpg"
        
        if download_image(img_data["url"], raw_path):
            effect = effects[downloaded % len(effects)]
            if process_image_for_shorts(raw_path, proc_path, effect=effect):
                processed_paths.append(str(proc_path))
                downloaded += 1
                print(f"  ✅ Image {downloaded}/{target_count} ready")
    
    # Fill remaining with fallback images
    fallback_colors = [
        (15, 10, 40), (40, 10, 10), (10, 30, 40),
        (30, 20, 5), (10, 40, 20), (40, 5, 30)
    ]
    while len(processed_paths) < target_count:
        idx = len(processed_paths)
        proc_path = output_dir / f"img_{idx:03d}.jpg"
        color = fallback_colors[idx % len(fallback_colors)]
        create_fallback_image(str(proc_path), text=queries[idx % len(queries)], color=color)
        processed_paths.append(str(proc_path))
        print(f"  🎨 Fallback image {len(processed_paths)}/{target_count}")
    
    print(f"✅ Total images ready: {len(processed_paths)}")
    return processed_paths


if __name__ == "__main__":
    queries = ["Taj Mahal sunset", "Mughal architecture", "Islamic art"]
    paths = fetch_all_images(queries, "/tmp/test_images", target_count=3)
    print(f"Downloaded: {paths}")
