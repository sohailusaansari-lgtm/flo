#!/data/data/com.termux/files/usr/bin/bash
# Termux Setup Script for Mughal Shorts Bot
# Run: chmod +x termux_setup.sh && ./termux_setup.sh

echo "============================================"
echo "  Mughal/Ocean/Islam YouTube Shorts Bot"
echo "  Termux Setup Script"
echo "============================================"
echo ""

# Update packages
echo "📦 Updating packages..."
pkg update -y && pkg upgrade -y

# Install system dependencies
echo "📦 Installing system packages..."
pkg install -y python ffmpeg git libjpeg-turbo libpng clang

# Install font
echo "🔤 Installing fonts..."
pkg install -y fontconfig
mkdir -p ~/.termux/font 2>/dev/null || true

# Install Python dependencies
echo "🐍 Installing Python packages..."
pip install --upgrade pip

# Install in order (some need compilation)
pip install Pillow --no-cache-dir
pip install numpy --no-cache-dir
pip install moviepy==1.0.3 --no-cache-dir
pip install gTTS --no-cache-dir
pip install python-telegram-bot==20.7 --no-cache-dir
pip install google-generativeai --no-cache-dir
pip install google-api-python-client google-auth-oauthlib google-auth-httplib2 --no-cache-dir
pip install python-dotenv requests schedule apscheduler pytz --no-cache-dir
pip install imageio imageio-ffmpeg pydub --no-cache-dir

echo ""
echo "✅ All packages installed!"
echo ""

# Check ffmpeg
if command -v ffmpeg &> /dev/null; then
    echo "✅ ffmpeg: $(ffmpeg -version 2>&1 | head -1)"
else
    echo "❌ ffmpeg not found! Run: pkg install ffmpeg"
fi

# Check Python
echo "✅ Python: $(python --version)"

echo ""
echo "============================================"
echo "  Next Steps:"
echo "============================================"
echo ""
echo "1. Copy .env.example to .env:"
echo "   cp .env.example .env"
echo ""
echo "2. Edit .env with your API keys:"
echo "   nano .env"
echo ""
echo "3. Setup YouTube authentication:"
echo "   python auth.py"
echo ""
echo "4. Start the bot:"
echo "   python main.py"
echo ""
echo "============================================"
