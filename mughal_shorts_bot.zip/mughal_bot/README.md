# 🎬 Mughal / Ocean / Islam — YouTube Shorts Auto-Bot

An AI-powered bot that automatically generates and uploads YouTube Shorts every 5 hours.
Controlled entirely via Telegram. Runs on **Railway**, **Termux**, or any Linux server.

---

## 🚀 Features

- 🤖 **Telegram Control** — `/start`, Generate, Custom Topic buttons
- 🧠 **Gemini AI** — Generates unique scripts every time
- 🗣️ **Realistic Voice** — ElevenLabs (primary) or gTTS (fallback)
- 🖼️ **30 Images per Video** — Fetched from Unsplash + Pexels
- 📝 **Big Bold Subtitles** — Synced perfectly to narration
- 🎨 **Cinematic Thumbnails** — Auto-generated, eye-catching
- ⏰ **Auto-Schedule** — New video every 5 hours
- 📤 **Auto YouTube Upload** — Publishes as YouTube Shorts

---

## 📁 File Structure

```
mughal_bot/
├── main.py              # Telegram bot + scheduler
├── pipeline.py          # Full video creation pipeline
├── content_generator.py # Gemini AI script generator
├── image_fetcher.py     # Unsplash + Pexels image downloader
├── voice_generator.py   # ElevenLabs + gTTS voice synthesis
├── thumbnail_generator.py # YouTube thumbnail creator
├── video_producer.py    # ffmpeg video assembler
├── youtube_uploader.py  # YouTube API uploader
├── auth.py              # YouTube OAuth2 authentication
├── requirements.txt     # Python dependencies
├── .env.example         # Environment variables template
├── railway.json         # Railway deployment config
├── nixpacks.toml        # Railway build config
├── Procfile             # Process definition
└── termux_setup.sh      # Termux install script
```

---

## 🔧 Setup

### Step 1: Get API Keys

| Service | Where to Get | Used For |
|---------|-------------|---------|
| **Telegram Bot Token** | [@BotFather](https://t.me/BotFather) → `/newbot` | Bot control |
| **Telegram Chat ID** | [@userinfobot](https://t.me/userinfobot) | Auto notifications |
| **Gemini API Key** | [Google AI Studio](https://aistudio.google.com) | Script generation |
| **ElevenLabs API Key** | [ElevenLabs.io](https://elevenlabs.io) | Realistic voice |
| **YouTube OAuth2** | [Google Cloud Console](https://console.cloud.google.com) | Video upload |
| **Unsplash Access Key** | [Unsplash Developers](https://unsplash.com/developers) | Images |
| **Pexels API Key** | [Pexels API](https://www.pexels.com/api/) | Images (backup) |

### Step 2: YouTube OAuth2 Setup (Google Cloud Console)

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project or select existing
3. Enable **YouTube Data API v3**
4. Go to **Credentials** → **Create Credentials** → **OAuth 2.0 Client IDs**
5. Application type: **Desktop app**
6. Download the credentials (or copy Client ID + Secret)
7. Add your Google account to **Test Users** (OAuth consent screen)

### Step 3: Configure .env

```bash
cp .env.example .env
nano .env  # or edit with any text editor
```

Fill in all your API keys.

---

## 🖥️ Running on Termux (Android)

```bash
# 1. Install Termux from F-Droid (NOT Play Store)
# 2. Clone or copy the project
git clone <your-repo> mughal_bot
cd mughal_bot

# 3. Run setup script
chmod +x termux_setup.sh
./termux_setup.sh

# 4. Configure .env
cp .env.example .env
nano .env

# 5. Authenticate YouTube (one-time)
python auth.py

# 6. Start the bot
python main.py

# 7. Keep running in background with tmux
pkg install tmux
tmux new -s bot
python main.py
# Press Ctrl+B then D to detach
```

---

## 🚂 Deploying on Railway

### Method 1: GitHub (Recommended)

1. Push code to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin <your-github-repo>
   git push -u origin main
   ```

2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub

3. Add environment variables in Railway dashboard:
   - Copy all values from your `.env` file
   - Add them one by one in Railway's Variables section

4. **Important**: Run auth.py locally first to generate `token.pickle`, then add it to your repo or set up a way to persist it.

### Method 2: Railway CLI

```bash
npm install -g @railway/cli
railway login
railway init
railway up
```

### Persisting YouTube Token on Railway

Since Railway doesn't persist files between deploys, store the token as a base64 env var:

```bash
# After running auth.py locally:
base64 token.pickle > token_b64.txt

# Add TOKEN_PICKLE_B64 env var in Railway with content of token_b64.txt
```

Then add this to the top of `auth.py`:
```python
# Auto-restore token from env var (for Railway)
if os.getenv("TOKEN_PICKLE_B64") and not Path("token.pickle").exists():
    import base64
    with open("token.pickle", "wb") as f:
        f.write(base64.b64decode(os.getenv("TOKEN_PICKLE_B64")))
```

---

## 🤖 Telegram Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Show main menu with buttons |
| `/generate` | Generate video with random topic |
| `/prompt` | Create video with your custom topic |
| `/status` | Check bot and API status |
| `/recent` | See recent YouTube uploads |
| `/schedule` | Auto-schedule information |
| `/help` | Show all commands |
| `/cancel` | Cancel current conversation |

### Inline Buttons

- **🎬 Generate Video** — Random topic from pool
- **✍️ Custom Topic** — You provide the topic
- **📊 Status** — API health check
- **📺 Recent Videos** — Latest uploads
- **⏰ Schedule Info** — Next auto-run time

---

## 🎯 Topic Pool

The bot randomly selects from these categories:

**Mughal History**
- Emperor Akbar's Golden Era, Taj Mahal Secrets, Shah Jahan's Love Story, Mughal Architecture, etc.

**Ocean Facts**
- Mariana Trench, Bioluminescent Creatures, Deep Sea Monsters, Bermuda Triangle, etc.

**Islam & Quran**
- Quran Miracles & Science, Prophet Muhammad's Life, Islamic Golden Age, Zamzam Water, etc.

---

## 📹 Video Specs

| Property | Value |
|----------|-------|
| Format | MP4 (H.264) |
| Resolution | 1080 × 1920 (9:16) |
| Duration | 40–55 seconds |
| FPS | 30 |
| Audio | AAC 192kbps |
| Images | 30 per video |
| Subtitles | Embedded (bold, yellow) |
| Thumbnail | 1080 × 1920 JPEG |

---

## ⚠️ Troubleshooting

**"Voice generation failed"**
- Check `ELEVENLABS_API_KEY` — gTTS will be used as fallback automatically

**"YouTube upload failed"**
- Run `python auth.py` to refresh authentication
- Check YouTube Data API v3 is enabled in Google Cloud Console
- Verify your account is in OAuth test users list

**"No images downloaded"**
- Check `UNSPLASH_ACCESS_KEY` and `PEXELS_API_KEY`
- Fallback colored images will be used automatically

**"ffmpeg not found"**
- Termux: `pkg install ffmpeg`
- Ubuntu/Debian: `sudo apt install ffmpeg`
- Railway: Already included via nixpacks.toml

**Bot not responding**
- Check `TELEGRAM_BOT_TOKEN` is correct
- Make sure bot is started with `/start` on Telegram

---

## 📊 Cost Estimates (Monthly, 5hr schedule = ~144 videos/month)

| Service | Free Tier | Cost if exceeded |
|---------|-----------|-----------------|
| Gemini AI | 60 req/min free | Very cheap |
| ElevenLabs | 10,000 chars/mo free | ~$5/mo |
| Unsplash | 50 req/hr free | Free (sufficient) |
| Pexels | Unlimited free | Free |
| YouTube API | 10,000 units/day free | Free |
| Railway | $5/mo hobby plan | $5/mo |

**Total: ~$5-10/month** for 144 automatic YouTube Shorts!

---

## 📄 License

MIT License — Use freely for personal and commercial projects.
