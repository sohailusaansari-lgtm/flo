"""
pipeline.py - Full video creation pipeline
Orchestrates: Content → Images → Voice → Video → Upload
"""

import os
import time
import shutil
import asyncio
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

OUTPUT_BASE = Path("outputs")


def notify_telegram(bot, chat_id, message):
    """Send update to Telegram (sync wrapper)"""
    try:
        import asyncio
        loop = asyncio.new_event_loop()
        loop.run_until_complete(bot.send_message(chat_id=chat_id, text=message))
        loop.close()
    except Exception as e:
        print(f"⚠️  Telegram notify error: {e}")


async def notify_async(bot, chat_id, message):
    """Send update to Telegram (async)"""
    try:
        await bot.send_message(chat_id=chat_id, text=message, parse_mode="HTML")
    except Exception as e:
        print(f"⚠️  Telegram notify error: {e}")


async def run_pipeline(topic=None, bot=None, chat_id=None, status_message_id=None):
    """
    Full pipeline: topic → video → YouTube upload
    
    Args:
        topic: Custom topic or None for random
        bot: Telegram bot instance for notifications
        chat_id: Telegram chat ID
        status_message_id: Message ID to edit for status updates
    
    Returns: dict with results
    """
    start_time = time.time()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    work_dir = OUTPUT_BASE / timestamp
    work_dir.mkdir(parents=True, exist_ok=True)

    async def update_status(msg):
        print(f"📊 {msg}")
        if bot and chat_id:
            try:
                if status_message_id:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=status_message_id,
                        text=f"⚙️ <b>Pipeline Status</b>\n\n{msg}",
                        parse_mode="HTML"
                    )
                else:
                    await bot.send_message(
                        chat_id=chat_id,
                        text=f"📊 {msg}",
                        parse_mode="HTML"
                    )
            except Exception:
                pass

    result = {
        "success": False,
        "topic": topic,
        "video_path": None,
        "thumbnail_path": None,
        "youtube_url": None,
        "youtube_id": None,
        "duration": 0,
        "error": None,
    }

    try:
        # ── STEP 1: Generate Content ──────────────────────────
        await update_status("🧠 <b>Step 1/6:</b> Generating script with AI...")

        from content_generator import get_random_topic, generate_video_script, generate_subtitle_segments

        if not topic:
            topic = get_random_topic()

        result["topic"] = topic
        print(f"\n🎯 Topic: {topic}\n")

        script_data = generate_video_script(topic)
        title = script_data["title"]
        description = script_data["description"]
        script = script_data["script"]
        tags = script_data.get("tags", [])
        image_queries = script_data["image_search_queries"]
        thumbnail_text = script_data.get("thumbnail_text", topic[:30])
        subtitle_segments = generate_subtitle_segments(script)

        print(f"📝 Title: {title}")
        print(f"📜 Script: {len(script.split())} words")

        # ── STEP 2: Generate Voice ────────────────────────────
        await update_status(f"🎙️ <b>Step 2/6:</b> Generating voice narration...\n<i>{title[:60]}</i>")

        from voice_generator import generate_voice

        audio_path = work_dir / "narration.mp3"
        audio_out, audio_duration = generate_voice(script, str(audio_path))

        if not audio_out:
            raise Exception("Voice generation failed")

        print(f"🔊 Audio: {audio_duration:.1f}s")

        # Clamp duration
        audio_duration = max(40, min(55, audio_duration))

        # ── STEP 3: Fetch Images ──────────────────────────────
        await update_status(f"🖼️ <b>Step 3/6:</b> Fetching 30 images from web...\n<i>This may take ~60 seconds</i>")

        from image_fetcher import fetch_all_images

        images_dir = work_dir / "images"
        image_paths = fetch_all_images(
            queries=image_queries,
            output_dir=str(images_dir),
            target_count=30
        )

        print(f"🖼️ Images: {len(image_paths)} ready")

        # ── STEP 4: Create Thumbnail ──────────────────────────
        await update_status("🎨 <b>Step 4/6:</b> Creating thumbnail...")

        from thumbnail_generator import create_thumbnail

        thumbnail_path = work_dir / "thumbnail.jpg"
        bg_image = image_paths[0] if image_paths else None

        create_thumbnail(
            text=thumbnail_text,
            output_path=str(thumbnail_path),
            background_image_path=bg_image,
            subtitle=title[:40] if len(title) > 40 else None
        )
        result["thumbnail_path"] = str(thumbnail_path)

        # ── STEP 5: Produce Video ─────────────────────────────
        await update_status("🎬 <b>Step 5/6:</b> Producing video (30 images + subtitles)...\n<i>This takes 2-4 minutes</i>")

        from video_producer import produce_video

        video_dir = work_dir / "video"
        video_path = produce_video(
            image_paths=image_paths,
            audio_path=str(audio_out),
            subtitle_segments=subtitle_segments,
            output_dir=str(video_dir),
            topic=topic,
            audio_duration=audio_duration
        )

        if not video_path:
            raise Exception("Video production failed")

        result["video_path"] = video_path
        print(f"🎬 Video: {video_path}")

        # ── STEP 6: Upload to YouTube ─────────────────────────
        await update_status("📤 <b>Step 6/6:</b> Uploading to YouTube Shorts...")

        from youtube_uploader import upload_to_youtube

        video_id = upload_to_youtube(
            video_path=video_path,
            title=title,
            description=description,
            tags=tags,
            thumbnail_path=str(thumbnail_path),
            privacy="public"
        )

        elapsed = time.time() - start_time

        if video_id:
            yt_url = f"https://www.youtube.com/shorts/{video_id}"
            result["youtube_id"] = video_id
            result["youtube_url"] = yt_url
            result["success"] = True
            result["duration"] = elapsed

            success_msg = (
                f"✅ <b>Video Published!</b>\n\n"
                f"🎯 <b>Topic:</b> {topic}\n"
                f"📌 <b>Title:</b> {title}\n"
                f"🔗 <b>URL:</b> {yt_url}\n"
                f"⏱️ <b>Pipeline time:</b> {elapsed/60:.1f} minutes"
            )
            await update_status(success_msg)
        else:
            # Upload failed but video was created
            result["success"] = True  # partial success
            result["duration"] = elapsed
            
            fail_msg = (
                f"⚠️ <b>Video created but upload failed!</b>\n\n"
                f"🎯 <b>Topic:</b> {topic}\n"
                f"📌 <b>Title:</b> {title}\n"
                f"📁 <b>Video saved at:</b> {video_path}\n\n"
                f"Check YouTube auth with: python auth.py"
            )
            await update_status(fail_msg)

        # Send thumbnail to Telegram
        if bot and chat_id and thumbnail_path.exists():
            try:
                with open(str(thumbnail_path), "rb") as f:
                    await bot.send_photo(
                        chat_id=chat_id,
                        photo=f,
                        caption=f"🖼️ Thumbnail for: <b>{title}</b>",
                        parse_mode="HTML"
                    )
            except Exception as e:
                print(f"⚠️  Could not send thumbnail: {e}")

    except Exception as e:
        elapsed = time.time() - start_time
        result["error"] = str(e)
        result["duration"] = elapsed
        error_msg = f"❌ <b>Pipeline Error:</b>\n<code>{str(e)[:300]}</code>"
        print(f"❌ Pipeline error: {e}")
        import traceback
        traceback.print_exc()
        await update_status(error_msg)

    finally:
        # Cleanup work dir (keep outputs for debugging)
        pass

    return result


if __name__ == "__main__":
    # Test pipeline without Telegram
    result = asyncio.run(run_pipeline(topic="Taj Mahal secrets"))
    print(f"\nResult: {result}")
