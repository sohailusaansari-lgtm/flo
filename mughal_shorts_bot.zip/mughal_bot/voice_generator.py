"""
voice_generator.py - Voice via ElevenLabs REST API or gTTS fallback
No SDK needed — plain requests only.
"""

import os
import subprocess
import requests
from dotenv import load_dotenv

load_dotenv()

ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY")
ELEVENLABS_VOICE_ID = os.getenv("ELEVENLABS_VOICE_ID", "pNInz6obpgDQGcFmaJgB")  # Adam


def generate_voice_elevenlabs(text, output_path):
    """ElevenLabs TTS via REST API."""
    if not ELEVENLABS_API_KEY:
        return False

    url = f"https://api.elevenlabs.io/v1/text-to-speech/{ELEVENLABS_VOICE_ID}"
    headers = {
        "Accept": "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": ELEVENLABS_API_KEY,
    }
    payload = {
        "text": text,
        "model_id": "eleven_monolingual_v1",
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.75,
            "style": 0.3,
            "use_speaker_boost": True,
        },
    }
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=60)
        resp.raise_for_status()
        with open(output_path, "wb") as f:
            f.write(resp.content)
        print(f"✅ ElevenLabs voice: {output_path}")
        return True
    except Exception as e:
        print(f"⚠️  ElevenLabs failed: {e}")
        return False


def generate_voice_gtts(text, output_path):
    """gTTS fallback — pure Python, no compilation needed."""
    try:
        from gtts import gTTS
        tts = gTTS(text=text, lang="en", slow=False, tld="com")
        tts.save(output_path)
        print(f"✅ gTTS voice: {output_path}")
        return True
    except Exception as e:
        print(f"❌ gTTS failed: {e}")
        return False


def get_audio_duration(audio_path):
    """Get duration in seconds via ffprobe."""
    try:
        cmd = [
            "ffprobe", "-v", "quiet",
            "-show_entries", "format=duration",
            "-of", "csv=p=0",
            str(audio_path),
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        return float(result.stdout.strip())
    except Exception:
        return None


def generate_voice(text, output_path):
    """
    Generate voice audio. Returns (path, duration_seconds) or (None, None).
    Tries ElevenLabs first, falls back to gTTS.
    """
    output_path = str(output_path)
    if not output_path.endswith(".mp3"):
        output_path = output_path.rsplit(".", 1)[0] + ".mp3"

    success = False

    if ELEVENLABS_API_KEY:
        print("🎙️  Generating voice with ElevenLabs...")
        success = generate_voice_elevenlabs(text, output_path)

    if not success:
        print("🎙️  Generating voice with gTTS...")
        success = generate_voice_gtts(text, output_path)

    if not success:
        print("❌ All voice generation methods failed")
        return None, None

    duration = get_audio_duration(output_path)
    if duration is None:
        duration = len(text.split()) / 2.5  # fallback estimate
    print(f"  Duration: {duration:.1f}s")
    return output_path, duration


if __name__ == "__main__":
    path, dur = generate_voice(
        "The Mughal Empire was one of the greatest empires in history.",
        "/tmp/test_voice.mp3"
    )
    print(f"Result: {path}, {dur:.1f}s")
