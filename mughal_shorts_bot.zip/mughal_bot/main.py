"""
main.py - Telegram Bot + Scheduler
PTB installed WITHOUT job-queue extra to avoid apscheduler/tzdata crash on Termux.
Install with: pip install "python-telegram-bot==21.6" --no-deps
              pip install httpx httpcore anyio certifi h11
"""

import os
import asyncio
import logging
import time
from datetime import datetime, timedelta
from dotenv import load_dotenv

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters, ConversationHandler
)

load_dotenv()

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

BOT_TOKEN      = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID        = os.getenv("TELEGRAM_CHAT_ID")
SCHEDULE_HOURS = int(os.getenv("AUTO_SCHEDULE_HOURS", "5"))

WAITING_FOR_TOPIC = 1
pipeline_running  = False
START_TIME        = time.time()
NEXT_AUTO_RUN     = datetime.utcnow() + timedelta(hours=SCHEDULE_HOURS)


# ── Keyboard ────────────────────────────────────────────────────────────────

def main_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🎬 Generate Video", callback_data="generate"),
            InlineKeyboardButton("✍️ Custom Topic",   callback_data="prompt"),
        ],
        [
            InlineKeyboardButton("📊 Status",         callback_data="status"),
            InlineKeyboardButton("📺 Recent Videos",  callback_data="recent"),
        ],
        [
            InlineKeyboardButton("⏰ Schedule Info",  callback_data="schedule"),
        ],
    ])


def back_keyboard():
    return InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="back_menu")]])


def format_uptime():
    s = int(time.time() - START_TIME)
    return f"{s // 3600}h {(s % 3600) // 60}m"


# ── Commands ────────────────────────────────────────────────────────────────

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = (
        f"👋 Welcome, <b>{user.first_name}</b>!\n\n"
        f"🎬 <b>Mughal History · Ocean Facts · Islam & Quran</b>\n"
        f"<i>AI-Powered YouTube Shorts Generator</i>\n\n"
        f"📌 <b>Features:</b>\n"
        f"• 30 curated images per video\n"
        f"• AI-generated scripts (Gemini)\n"
        f"• Realistic human-like voice\n"
        f"• Bold subtitles synced to narration\n"
        f"• Auto-publish to YouTube Shorts\n"
        f"• New video every <b>{SCHEDULE_HOURS} hours</b>\n\n"
        f"👇 Choose an action:"
    )
    if update.message:
        await update.message.reply_text(text, reply_markup=main_keyboard(), parse_mode="HTML")
    else:
        await update.callback_query.edit_message_text(text, reply_markup=main_keyboard(), parse_mode="HTML")


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 <b>Commands</b>\n\n"
        "/start — Main menu\n"
        "/generate — Random topic video\n"
        "/prompt — Custom topic video\n"
        "/status — Bot & API status\n"
        "/recent — Recent YouTube uploads\n"
        "/schedule — Schedule info\n"
        "/cancel — Cancel input\n"
        "/help — This message",
        parse_mode="HTML"
    )


async def generate_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await trigger_pipeline(update, context, topic=None)


async def prompt_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "✍️ <b>Custom Topic Mode</b>\n\n"
        "Send me your topic and I'll make a video!\n\n"
        "💡 <b>Examples:</b>\n"
        "• <code>Aurangzeb's last days</code>\n"
        "• <code>Deep ocean monsters</code>\n"
        "• <code>Miracles in the Quran</code>\n"
        "• <code>Mughal food culture</code>\n\n"
        "📝 What topic?"
    )
    if update.message:
        await update.message.reply_text(text, parse_mode="HTML")
    else:
        await update.callback_query.answer()
        await update.callback_query.message.reply_text(text, parse_mode="HTML")
    return WAITING_FOR_TOPIC


async def receive_topic(update: Update, context: ContextTypes.DEFAULT_TYPE):
    topic = update.message.text.strip()
    if len(topic) < 3:
        await update.message.reply_text("⚠️ Too short. Try again!")
        return WAITING_FOR_TOPIC
    if len(topic) > 200:
        await update.message.reply_text("⚠️ Too long (max 200 chars). Try again!")
        return WAITING_FOR_TOPIC
    await update.message.reply_text(
        f"✅ Topic received:\n<b>«{topic}»</b>\n\n⏳ Starting pipeline...",
        parse_mode="HTML"
    )
    await trigger_pipeline(update, context, topic=topic)
    return ConversationHandler.END


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("❌ Cancelled.", reply_markup=main_keyboard())
    return ConversationHandler.END


# ── Pipeline ────────────────────────────────────────────────────────────────

async def trigger_pipeline(update: Update, context: ContextTypes.DEFAULT_TYPE, topic=None):
    global pipeline_running
    if pipeline_running:
        msg = "⏳ <b>Pipeline already running!</b> Please wait."
        if update.callback_query:
            await update.callback_query.answer("Already running!", show_alert=True)
            await update.callback_query.message.reply_text(msg, parse_mode="HTML")
        else:
            await update.message.reply_text(msg, parse_mode="HTML")
        return

    pipeline_running = True
    chat_id = update.effective_chat.id

    if update.callback_query:
        await update.callback_query.answer()
        status_msg = await update.callback_query.message.reply_text(
            "⚙️ <b>Pipeline Status</b>\n\n🚀 Starting...", parse_mode="HTML"
        )
    else:
        status_msg = await update.message.reply_text(
            "⚙️ <b>Pipeline Status</b>\n\n🚀 Starting...", parse_mode="HTML"
        )

    asyncio.create_task(
        run_pipeline_task(context.bot, chat_id, status_msg.message_id, topic)
    )


async def run_pipeline_task(bot, chat_id, status_msg_id, topic=None):
    global pipeline_running, NEXT_AUTO_RUN
    try:
        from pipeline import run_pipeline
        await run_pipeline(topic=topic, bot=bot, chat_id=chat_id,
                           status_message_id=status_msg_id)
        NEXT_AUTO_RUN = datetime.utcnow() + timedelta(hours=SCHEDULE_HOURS)
    except Exception as e:
        logger.error(f"Pipeline error: {e}", exc_info=True)
        try:
            await bot.send_message(chat_id=chat_id,
                text=f"❌ Pipeline error:\n<code>{str(e)[:300]}</code>",
                parse_mode="HTML")
        except Exception:
            pass
    finally:
        pipeline_running = False
    try:
        await bot.send_message(chat_id=chat_id, text="✅ Done! What next?",
            reply_markup=main_keyboard(), parse_mode="HTML")
    except Exception:
        pass


# ── Callbacks ───────────────────────────────────────────────────────────────

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.callback_query.data
    if data == "generate":
        await trigger_pipeline(update, context, topic=None)
    elif data == "prompt":
        await prompt_command(update, context)
    elif data == "status":
        await show_status(update, context)
    elif data == "recent":
        await show_recent_videos(update, context)
    elif data == "schedule":
        await show_schedule(update, context)
    elif data == "back_menu":
        await start_command(update, context)


async def show_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    secs = max(0, (NEXT_AUTO_RUN - datetime.utcnow()).total_seconds())
    checks = {
        "Telegram Bot": bool(os.getenv("TELEGRAM_BOT_TOKEN")),
        "Gemini AI":    bool(os.getenv("GEMINI_API_KEY")),
        "ElevenLabs":   bool(os.getenv("ELEVENLABS_API_KEY")),
        "YouTube":      bool(os.getenv("YOUTUBE_CLIENT_ID")),
        "Unsplash":     bool(os.getenv("UNSPLASH_ACCESS_KEY")),
        "Pexels":       bool(os.getenv("PEXELS_API_KEY")),
    }
    env_lines = "\n".join(f"{'✅' if v else '❌'} {k}" for k, v in checks.items())
    await q.edit_message_text(
        f"📊 <b>Status</b>\n\n"
        f"🤖 Pipeline: <b>{'🔄 Running' if pipeline_running else '✅ Idle'}</b>\n"
        f"⏱️ Uptime: <b>{format_uptime()}</b>\n"
        f"⏰ Next auto-run: <b>{int(secs//3600)}h {int((secs%3600)//60)}m</b>\n"
        f"🔁 Every <b>{SCHEDULE_HOURS}h</b>\n\n"
        f"🔧 <b>APIs:</b>\n{env_lines}",
        parse_mode="HTML", reply_markup=back_keyboard()
    )


async def show_recent_videos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer("Fetching...")
    try:
        from youtube_uploader import get_recent_uploads
        videos = get_recent_uploads(max_results=5)
        if videos:
            lines = [f"{i}. <a href='{v['url']}'>{v['title'][:45]}</a>\n   📅 {v['published'][:10]}"
                     for i, v in enumerate(videos, 1)]
            text = "📺 <b>Recent Uploads:</b>\n\n" + "\n\n".join(lines)
        else:
            text = "📺 No uploads yet. Hit Generate!"
    except Exception as e:
        text = f"⚠️ Error: {str(e)[:150]}"
    await q.edit_message_text(text, parse_mode="HTML",
        disable_web_page_preview=True, reply_markup=back_keyboard())


async def show_schedule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Works from both command and callback
    secs = max(0, (NEXT_AUTO_RUN - datetime.utcnow()).total_seconds())
    text = (
        f"⏰ <b>Auto-Schedule</b>\n\n"
        f"🔁 Every <b>{SCHEDULE_HOURS} hours</b>\n"
        f"⏳ Next video in: <b>{int(secs//3600)}h {int((secs%3600)//60)}m</b>\n\n"
        f"📌 <b>Topic pool:</b>\n• Mughal History\n• Ocean Facts\n• Islam & Quran\n\n"
        f"💡 Use <b>Custom Topic</b> to override!"
    )
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, parse_mode="HTML",
            reply_markup=back_keyboard())
    else:
        await update.message.reply_text(text, parse_mode="HTML",
            reply_markup=back_keyboard())


# ── Pure-asyncio scheduler (no apscheduler / no tzdata needed) ─────────────

async def auto_scheduler(bot):
    """Fires pipeline every SCHEDULE_HOURS hours using plain asyncio.sleep."""
    global pipeline_running, NEXT_AUTO_RUN
    logger.info(f"⏰ Scheduler sleeping {SCHEDULE_HOURS}h before first auto-run")
    await asyncio.sleep(SCHEDULE_HOURS * 3600)

    while True:
        logger.info("⏰ Auto-scheduler triggered!")
        NEXT_AUTO_RUN = datetime.utcnow() + timedelta(hours=SCHEDULE_HOURS)

        if not pipeline_running and CHAT_ID:
            pipeline_running = True
            try:
                status_msg = await bot.send_message(
                    chat_id=CHAT_ID,
                    text="⏰ <b>Auto-Schedule</b>\n\n⚙️ Starting pipeline...",
                    parse_mode="HTML"
                )
                from pipeline import run_pipeline
                result = await run_pipeline(
                    topic=None, bot=bot, chat_id=CHAT_ID,
                    status_message_id=status_msg.message_id
                )
                if result.get("youtube_url"):
                    await bot.send_message(
                        chat_id=CHAT_ID,
                        text=(
                            f"✅ <b>Published!</b>\n"
                            f"🎯 {result['topic']}\n"
                            f"🔗 {result['youtube_url']}\n\n"
                            f"⏰ Next in {SCHEDULE_HOURS}h"
                        ),
                        parse_mode="HTML", reply_markup=main_keyboard()
                    )
            except Exception as e:
                logger.error(f"Auto-generate error: {e}", exc_info=True)
                try:
                    await bot.send_message(
                        chat_id=CHAT_ID,
                        text=f"❌ Auto-generate failed:\n<code>{str(e)[:200]}</code>",
                        parse_mode="HTML"
                    )
                except Exception:
                    pass
            finally:
                pipeline_running = False

        await asyncio.sleep(SCHEDULE_HOURS * 3600)


# ── post_init: runs after bot is ready ─────────────────────────────────────

async def post_init(app: Application):
    asyncio.create_task(auto_scheduler(app.bot))
    if CHAT_ID:
        try:
            await app.bot.send_message(
                chat_id=CHAT_ID,
                text=f"🚀 <b>Bot Started!</b>\n\nAuto-generating every <b>{SCHEDULE_HOURS}h</b> 👇",
                parse_mode="HTML", reply_markup=main_keyboard()
            )
        except Exception as e:
            logger.warning(f"Startup notify failed: {e}")


# ── Main ────────────────────────────────────────────────────────────────────

def main():
    if not BOT_TOKEN:
        print("❌ TELEGRAM_BOT_TOKEN not set in .env!")
        return

    print(f"🤖 Starting bot  |  schedule every {SCHEDULE_HOURS}h")
    print("ℹ️  Make sure apscheduler is NOT installed:")
    print("   pip uninstall apscheduler -y")

    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    conv = ConversationHandler(
        entry_points=[
            CommandHandler("prompt", prompt_command),
            CallbackQueryHandler(prompt_command, pattern="^prompt$"),
        ],
        states={WAITING_FOR_TOPIC: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, receive_topic)
        ]},
        fallbacks=[CommandHandler("cancel", cancel_command)],
        allow_reentry=True,
    )

    app.add_handler(CommandHandler("start",    start_command))
    app.add_handler(CommandHandler("help",     help_command))
    app.add_handler(CommandHandler("generate", generate_command))
    app.add_handler(CommandHandler("schedule", show_schedule))
    app.add_handler(CommandHandler("recent",   show_recent_videos))
    app.add_handler(conv)
    app.add_handler(CallbackQueryHandler(button_handler))

    print("✅ Bot running! Press Ctrl+C to stop.")
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    main()
